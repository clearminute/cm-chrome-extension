export const PRODUCTIVE_KEY = 'productive';
export const SLIGHTLY_PRODUCTIVE_KEY = 'slightlyProductive';
export const NEUTRAL_KEY = 'neutral';
export const SLIGHTLY_DISTRACTING_KEY = 'slightlyDistracting';
export const DISTRACTING_KEY = 'distracting';
export const UNASSIGNED_KEY = 'unassigned';

export const AGGREGATED_CONTEXT_ID = 'aggregated_context';

import db from './db.js';

// TODO: centralize activity-related DB Queries here
// TODO: do the same for other models (stats, focsuSessions, etc...)
export default {
  async fetchAll() {},

  async fetchByTitle() {}
};

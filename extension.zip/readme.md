# About

Experimental chrome extension to track your time visiting websites. Uses local storage (indexDB) and powered by https://light.clearminute.com.

# Release

Before release, increase the version in manifest.json and build the frontend in popup/app via `yarn install & yarn build`
